define("ace/snippets/protobuf",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText = "";
exports.scope = "protobuf";

});
